import { NextResponse } from "next/server";
import { accessToken, getActiveListings, getOpenOrders, getOrder } from "@/lib/ebay";
import { db, dbAll } from "@/lib/supabase";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

function chunks<T>(rows: T[], size = 300) {
  const result: T[][] = [];
  for (let i = 0; i < rows.length; i += size) result.push(rows.slice(i, i + size));
  return result;
}

export async function POST() {
  try {
    const token = await accessToken();
    const listings = await getActiveListings(token);
    if (!listings.length) throw new Error("eBay returned zero active listings. No Supabase records were changed.");

    // The normal import is read-only against eBay and refreshes the Supabase catalog.
    await db("marketplace_listings?ebay_status=eq.active", { method: "PATCH", body: JSON.stringify({ ebay_status: "inactive", updated_at: new Date().toISOString() }) });
    // Remove stale Magic classifications before rebuilding them from the exact
    // eBay Store category assigned to each current listing.
    await db("marketplace_listings?game=eq.magic", { method: "PATCH", body: JSON.stringify({ game: "other", updated_at: new Date().toISOString() }) });
    for (const group of chunks(listings)) {
      const databaseRows = group.map(({ started_at: _startedAt, ...listing }) => listing);
      await db("marketplace_listings?on_conflict=ebay_listing_id", {
        method: "POST", headers: { Prefer: "resolution=merge-duplicates,return=minimal" }, body: JSON.stringify(databaseRows),
      });
    }

    const stored: any[] = [];
    const ids = listings.map(x => x.ebay_listing_id);
    for (const group of chunks(ids, 150)) {
      stored.push(...await db(`marketplace_listings?select=id,ebay_listing_id,match_key,title&ebay_listing_id=in.(${group.join(",")})`));
    }
    const listingMap = new Map(stored.map(x => [String(x.ebay_listing_id), x.id]));

    // Preserve the primary location carried by each active eBay listing.
    const primaryLocations = listings.filter(x => x.ebay_sku).map(x => ({
      listing_id: listingMap.get(x.ebay_listing_id), sku: x.ebay_sku,
      location_label: x.ebay_sku, status: "available", source: "ebay",
      updated_at: new Date().toISOString(),
    })).filter(x => x.listing_id);
    for (const group of chunks(primaryLocations)) {
      await db("physical_skus?on_conflict=sku", {
        method: "POST", headers: { Prefer: "resolution=merge-duplicates,return=minimal" }, body: JSON.stringify(group),
      });
    }

    // Attach every physical SKU from a CSV batch once its new eBay listing exists.
    const keyToIds = new Map<string, string[]>();
    for (const row of stored) if (row.match_key) keyToIds.set(row.match_key, [...(keyToIds.get(row.match_key) || []), row.id]);
    const pending = await dbAll("pending_skus?select=id,match_key,sku,location_label&order=id.asc");
    const attached: any[] = [], attachedIds: string[] = [];
    for (const row of pending || []) {
      const matches = keyToIds.get(row.match_key) || [];
      if (matches.length !== 1) continue;
      attached.push({ listing_id: matches[0], sku: row.sku, location_label: row.location_label, status: "available", source: "csv_intake", updated_at: new Date().toISOString() });
      attachedIds.push(row.id);
    }
    for (const group of chunks(attached)) await db("physical_skus?on_conflict=sku", { method: "POST", headers: { Prefer: "resolution=merge-duplicates,return=minimal" }, body: JSON.stringify(group) });
    for (const group of chunks(attachedIds, 100)) await db(`pending_skus?id=in.(${group.join(",")})`, { method: "DELETE" });

    // Rebuild quantity discrepancies without altering either eBay quantity or locations.
    await db("reconciliation_issues?status=eq.open", { method: "PATCH", body: JSON.stringify({ status: "resolved", last_seen_at: new Date().toISOString() }) });
    const differences = await db("listing_reconciliation?select=id,ebay_quantity,active_sku_count,difference&difference=neq.0");
    const issues = differences.map((x: any) => ({
      listing_id: x.id, issue_type: Number(x.difference) > 0 ? "missing_sku" : "extra_sku",
      ebay_quantity: x.ebay_quantity, active_sku_count: x.active_sku_count, status: "open",
      last_seen_at: new Date().toISOString(), details: { difference: x.difference },
    }));
    for (const group of chunks(issues)) {
      await db("reconciliation_issues?on_conflict=listing_id,issue_type", {
        method: "POST", headers: { Prefer: "resolution=merge-duplicates,return=minimal" }, body: JSON.stringify(group),
      });
    }

    let importedOrders = 0;
    let completedOrders = 0;
    try {
      const orders = await getOpenOrders(token);
      const legacyIds = [...new Set(orders.flatMap((order: any) => (order.lineItems || []).map((line: any) => String(line.legacyItemId || ""))).filter(Boolean))];
      const orderListings: any[] = [];
      for (const group of chunks(legacyIds, 150)) orderListings.push(...await db(`marketplace_listings?select=id,ebay_listing_id,title,ebay_sku,image_url&ebay_listing_id=in.(${group.join(",")})`));
      const orderListingMap = new Map(orderListings.map(x => [String(x.ebay_listing_id), x]));
      const orderIds = orders.map((x: any) => String(x.orderId));
      const existing: any[] = [];
      for (const group of chunks(orderIds, 100)) existing.push(...await db(`marketplace_orders?select=id,marketplace_order_id,listing_id&marketplace_order_id=in.(${group.join(",")})`));
      const existingMap = new Map(existing.map(x => [`${x.marketplace_order_id}|${x.listing_id}`, x]));
      for (const order of orders) for (const line of order.lineItems || []) {
        const listing = orderListingMap.get(String(line.legacyItemId || ""));
        if (!listing) continue;
        const rawPayload = {
          lineItemId: line.lineItemId,
          legacyItemId: line.legacyItemId,
          orderTotal: order.pricingSummary?.total?.value ?? null,
          lineTotal: line.lineItemCost?.value ?? null,
          currency: order.pricingSummary?.total?.currency ?? "USD",
        };
        const existingOrder = existingMap.get(`${order.orderId}|${listing.id}`);
        if (existingOrder) {
          await db(`marketplace_orders?id=eq.${existingOrder.id}`, { method: "PATCH", body: JSON.stringify({ raw_payload: rawPayload, order_title: listing.title }) });
          continue;
        }
        const soldQuantity = Math.max(1, Number(line.quantity || 1));
        const locations = await db(`physical_skus?select=id,sku,location_label,created_at&listing_id=eq.${listing.id}&status=eq.available&order=created_at.asc&limit=500`);
        // Pull the surviving eBay listing's own location first, then attached
        // duplicate/CSV locations in their original intake order.
        const pulled = [...(locations || [])]
          .sort((a: any, b: any) => Number(b.sku === listing.ebay_sku) - Number(a.sku === listing.ebay_sku) || String(a.created_at).localeCompare(String(b.created_at)))
          .slice(0, soldQuantity);
        const row = { marketplace: "ebay", marketplace_order_id: String(order.orderId), listing_id: listing.id,
          quantity: soldQuantity, fulfillment_status: "unfulfilled", refunded: false,
          ordered_at: order.creationDate || new Date().toISOString(), order_title: listing.title,
          pull_sku: pulled.length ? pulled.map((x: any) => x.sku).join(", ") : listing.ebay_sku || null,
          pull_location: pulled.length ? pulled.map((x: any) => x.location_label).join(", ") : listing.ebay_sku || null,
          sku_removed_at: null,
          raw_payload: rawPayload };
        await db("marketplace_orders?on_conflict=marketplace,marketplace_order_id,listing_id", {
          method: "POST", headers: { Prefer: "resolution=merge-duplicates,return=minimal" }, body: JSON.stringify(row),
        });
        for (const location of pulled) await db(`physical_skus?id=eq.${location.id}`, {
          method: "PATCH", body: JSON.stringify({ status: "allocated", source_order_id: String(order.orderId), updated_at: new Date().toISOString() }),
        });
        importedOrders += 1;
      }

      // Reconcile orders that were shipped or canceled directly on eBay after
      // they had already been allocated in this app.
      const openOrderIds = new Set(orders.map((order: any) => String(order.orderId)));
      const pendingEbayOrders = await dbAll("marketplace_orders?select=id,marketplace_order_id,listing_id,fulfillment_status&marketplace=eq.ebay&fulfillment_status=eq.unfulfilled&refunded=eq.false");
      const staleOrderIds = [...new Set((pendingEbayOrders || []).map((row: any) => String(row.marketplace_order_id)).filter((id: string) => !openOrderIds.has(id)))];
      for (const orderId of staleOrderIds) {
        const current: any = await getOrder(token, orderId);
        const fulfillment = String(current?.orderFulfillmentStatus || "").toUpperCase();
        const cancelState = String(current?.cancelStatus?.cancelState || "").toUpperCase();
        const canceled = cancelState === "CANCELED" || cancelState === "CANCELLED";
        if (!canceled && fulfillment !== "IN_PROGRESS" && fulfillment !== "FULFILLED") continue;
        const affected = (pendingEbayOrders || []).filter((row: any) => String(row.marketplace_order_id) === orderId);
        for (const row of affected) {
          const listingFilter = row.listing_id ? `&listing_id=eq.${row.listing_id}` : "";
          if (canceled) {
            await db(`physical_skus?source_order_id=eq.${encodeURIComponent(orderId)}&status=eq.allocated${listingFilter}`, {
              method: "PATCH", body: JSON.stringify({ status: "available", source_order_id: null, updated_at: new Date().toISOString() }),
            });
            await db(`marketplace_orders?id=eq.${row.id}`, {
              method: "PATCH", body: JSON.stringify({ fulfillment_status: "fulfilled", refunded: true }),
            });
          } else {
            await db(`physical_skus?source_order_id=eq.${encodeURIComponent(orderId)}&status=eq.allocated${listingFilter}`, { method: "DELETE" });
            await db(`marketplace_orders?id=eq.${row.id}`, {
              method: "PATCH", body: JSON.stringify({ fulfillment_status: "fulfilled", sku_removed_at: new Date().toISOString() }),
            });
          }
          completedOrders += 1;
        }
      }

      // Allocated SKUs remain in Supabase until the user explicitly confirms
      // shipment in the app or eBay reports that fulfillment has started.
    } catch (orderError) {
      return NextResponse.json({ ok: true, listings: listings.length, orders: 0, warning: `Listings imported. Orders could not be imported: ${orderError instanceof Error ? orderError.message : "unknown error"}` });
    }
    return NextResponse.json({ ok: true, listings: listings.length, magicSingles: listings.filter(x => x.game === "magic").length, orders: importedOrders, completedOrders });
  } catch (error) {
    return NextResponse.json({ ok: false, error: error instanceof Error ? error.message : "Sync failed" }, { status: 500 });
  }
}
