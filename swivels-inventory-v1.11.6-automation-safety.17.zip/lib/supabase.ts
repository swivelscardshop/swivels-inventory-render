const url = () => process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL || "";
const key = () => process.env.SUPABASE_SECRET_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY || "";

const headers = (extra: HeadersInit = {}) => {
  const apiKey = key();
  // Supabase's current sb_secret_ keys authenticate through the apikey header
  // and are not JWTs. Sending one as a Bearer token makes PostgREST try to
  // decode it as a JWT. Legacy service-role JWTs still need both headers.
  return {
    apikey: apiKey,
    ...(apiKey.startsWith("sb_secret_") ? {} : { Authorization: `Bearer ${apiKey}` }),
    ...extra,
  };
};

export function supabaseConfigured() {
  return Boolean(url() && key());
}

export async function db(path: string, init: RequestInit = {}) {
  if (!supabaseConfigured()) throw new Error("Supabase environment variables are missing");
  const response = await fetch(`${url()}/rest/v1/${path}`, {
    ...init,
    cache: "no-store",
    headers: {
      ...headers(),
      "Content-Type": "application/json",
      ...(init.headers || {}),
    },
  });
  if (!response.ok) {
    const body = await response.text();
    throw new Error(`Supabase ${response.status}: ${body.slice(0, 500)}`);
  }
  if (response.status === 204) return null;
  const text = await response.text();
  return text ? JSON.parse(text) : null;
}

export async function dbAll(path: string, pageSize = 1000) {
  const rows: any[] = [];
  let offset = 0;
  while (true) {
    const separator = path.includes("?") ? "&" : "?";
    const page = await db(`${path}${separator}limit=${pageSize}&offset=${offset}`);
    const batch = Array.isArray(page) ? page : [];
    rows.push(...batch);
    if (batch.length < pageSize) break;
    offset += batch.length;
    if (offset >= 50000) throw new Error("Stopped after 50,000 Supabase records for safety");
  }
  return rows;
}

export async function count(table: string, filter = "") {
  if (!supabaseConfigured()) return 0;
  const response = await fetch(`${url()}/rest/v1/${table}?select=id${filter}`, {
    cache: "no-store",
    headers: headers({ Prefer: "count=exact", Range: "0-0" }),
  });
  if (!response.ok) throw new Error(`Could not count ${table}: ${await response.text()}`);
  const range = response.headers.get("content-range") || "0/0";
  return Number(range.split("/")[1] || 0);
}
