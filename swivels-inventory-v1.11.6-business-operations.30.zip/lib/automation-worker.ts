import { db,count } from "@/lib/supabase";
import { getEbayWebhookStatus,configureEbayWebhooks,getActiveListingCount } from "@/lib/ebay";
import { listManaPoolWebhooks,registerManaPoolWebhook } from "@/lib/manapool";
import { repairMissingPrimarySkus } from "@/lib/sku-repair";
type State={started:boolean;busy:Set<string>}; const root=globalThis as typeof globalThis&{__swivelsWorker?:State};
async function save(values:Record<string,string>){await db("app_secrets?on_conflict=key",{method:"POST",headers:{Prefer:"resolution=merge-duplicates,return=minimal"},body:JSON.stringify(Object.entries(values).map(([key,value])=>({key,value:String(value).slice(0,1000),updated_at:new Date().toISOString()})))});}
async function json(response:Response){const value:any=await response.json().catch(()=>({}));if(!response.ok&&response.status!==207)throw new Error(value.error||`Automation failed (${response.status})`);return value;}
async function run(state:State,key:string,task:()=>Promise<void>){if(state.busy.has(key))return;state.busy.add(key);try{await task();}catch(error){await save({[`automation_${key}_result`]:`failed: ${error instanceof Error?error.message:"unknown error"}`}).catch(()=>{});}finally{state.busy.delete(key);}}
async function queue(state:State){await run(state,"queue",async()=>{
  const events=await db("rpc/claim_sync_events",{method:"POST",body:JSON.stringify({batch_limit:10})});
  const catalogEvents=(events||[]).filter((event:any)=>["ItemListed","ItemRevised","ItemClosed"].includes(event.event_type));
  let catalogError:Error|null=null;
  // A burst of scheduled listings can produce many notifications at once. One
  // full import sees the final eBay state for the entire batch, so never run a
  // 60+ call catalog scan once per notification.
  if(catalogEvents.length)try{
    const rows=await db("app_secrets?select=value&key=eq.automation_last_full_catalog_at&limit=1");
    const last=rows?.[0]?.value?Date.parse(rows[0].value):0;
    if(Date.now()-last>=30*60_000){
      await json(await(await import("@/app/api/sync/route")).POST());
      await save({automation_last_full_catalog_at:new Date().toISOString()});
    }
  }catch(error){catalogError=error instanceof Error?error:new Error("Catalog refresh failed");}
  for(const event of events||[])try{
    if(["ItemListed","ItemRevised","ItemClosed"].includes(event.event_type)){
      if(catalogError)throw catalogError;
    }else if(event.source==="manapool-webhook"||event.event_type==="order_created"){
      await json(await(await import("@/app/api/manapool/route")).PATCH());
    }else{
      await json(await(await import("@/app/api/orders/import/route")).POST());
    }
    await db(`sync_events?id=eq.${event.id}`,{method:"PATCH",body:JSON.stringify({status:"processed",error_message:null,processed_at:new Date().toISOString()})});
  }catch(error){await db(`sync_events?id=eq.${event.id}`,{method:"PATCH",body:JSON.stringify({status:"failed",error_message:error instanceof Error?error.message:"failed",processed_at:new Date().toISOString()})}).catch(()=>{});}
  await save({automation_worker_heartbeat:new Date().toISOString(),automation_worker_status:"running",automation_worker_error:""});
});}
async function recovery(state:State){await run(state,"last_recovery",async()=>{const ebay=await json(await(await import("@/app/api/orders/import/route")).POST()),mana=await json(await(await import("@/app/api/manapool/route")).PATCH());await save({automation_last_recovery_at:new Date().toISOString(),automation_last_recovery_result:`ok: eBay ${Number(ebay.imported||0)} new/${Number(ebay.updated||0)} refreshed; Mana Pool ${Number(mana.lines||0)} line(s)`});});}
async function verify(state:State){await run(state,"webhook",async()=>{const stored=await db("app_secrets?select=key,value&key=in.(webhook_base_url,manapool_webhook_secret)&limit=10"),values=Object.fromEntries((stored||[]).map((r:any)=>[r.key,r.value])),base=String(values.webhook_base_url||process.env.APP_BASE_URL||process.env.RENDER_EXTERNAL_URL||"").replace(/\/$/,"");if(!/^https:\/\//i.test(base))throw new Error("APP_BASE_URL is not configured");let ebay=await getEbayWebhookStatus(`${base}/api/webhooks/ebay`);if(!ebay.live)ebay=await configureEbayWebhooks(`${base}/api/webhooks/ebay`);const hooks=await listManaPoolWebhooks();let manaLive=(hooks?.webhooks||[]).some((r:any)=>String(r.topic)==="order_created"),extra:Record<string,string>={};if(!manaLive){const made=await registerManaPoolWebhook(`${base}/api/webhooks/manapool`);if(!made?.secret)throw new Error("Mana Pool webhook setup failed");extra.manapool_webhook_secret=String(made.secret);manaLive=true;}await save({...extra,webhook_base_url:base,automation_webhook_verified_at:new Date().toISOString(),automation_ebay_webhook_live:String(ebay.live),automation_manapool_webhook_live:String(manaLive),automation_webhook_error:""});});}
async function catalog(state:State){await run(state,"last_catalog",async()=>{const[ebay,stored]=await Promise.all([getActiveListingCount(),count("marketplace_listings","&ebay_status=eq.active")]),lastRows=await db("app_secrets?select=value&key=eq.automation_last_full_catalog_at&limit=1"),last=lastRows?.[0]?.value?Date.parse(lastRows[0].value):0,age=Date.now()-last;let message=`counts agree: ${ebay}`;if((ebay!==stored&&age>=30*60_000)||age>=2*60*60_000){const result=await json(await(await import("@/app/api/sync/route")).POST());message=`catalog refreshed: ${Number(result.listings||ebay)} active`;await save({automation_last_full_catalog_at:new Date().toISOString()});}else if(ebay!==stored){message=`count mismatch (${stored} stored / ${ebay} eBay); full scan cooling down`;}const repaired=await repairMissingPrimarySkus();if(repaired.repaired)message+=`; restored ${repaired.repaired} scheduled SKU(s)`;await save({automation_last_catalog_at:new Date().toISOString(),automation_last_catalog_result:message});});}
async function reconcile(state:State){await run(state,"last_reconciliation",async()=>{
  const result=await json(await(await import("@/app/api/exceptions/route")).GET()),now=new Date().toISOString();
  await save({automation_last_reconciliation_at:now,automation_last_reconciliation_result:`ok: ${Number(result.counts?.total||0)} item(s) need review`});
  const recent=await db(`reconciliation_runs?select=id&source=eq.automation-worker&started_at=gte.${encodeURIComponent(new Date(Date.now()-24*60*60_000).toISOString())}&limit=1`);
  if(!recent?.length){const[listings,skus]=await Promise.all([count("marketplace_listings","&ebay_status=eq.active"),count("physical_skus","&status=in.(available,allocated)")]);await db("reconciliation_runs",{method:"POST",headers:{Prefer:"return=minimal"},body:JSON.stringify({source:"automation-worker",status:"completed",listings_count:listings,sku_count:skus,issues_count:Number(result.counts?.total||0),summary:{counts:result.counts||{}},started_at:now,completed_at:now})});}
});}
async function mana(state:State){await run(state,"last_manapool_inventory",async()=>{const pending=await count("marketplace_listings","&game=eq.magic&ebay_status=eq.active&scryfall_id=is.null&manapool_mapping_status=eq.pending");let mapped=0;if(pending){const request=new Request("http://internal/api/manapool",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({mode:"map"})});mapped=Number((await json(await(await import("@/app/api/manapool/route")).POST(request))).matched||0);}const rows=await db("marketplace_listings?select=ebay_quantity,manapool_quantity&game=eq.magic&ebay_status=eq.active&scryfall_id=not.is.null&limit=10000"),lastRows=await db("app_secrets?select=value&key=eq.automation_last_manapool_inventory_at&limit=1"),last=lastRows?.[0]?.value?Date.parse(lastRows[0].value):0,due=mapped||(rows||[]).some((r:any)=>r.manapool_quantity===null||Number(r.manapool_quantity)!==Number(r.ebay_quantity))||Date.now()-last>24*60*60_000;let published=0;if(due){const request=new Request("http://internal/api/manapool",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({mode:"auto-sync"})});published=Number((await json(await(await import("@/app/api/manapool/route")).POST(request))).updated||0);await save({automation_last_manapool_inventory_at:new Date().toISOString()});}await save({automation_last_manapool_inventory_result:`ok: ${mapped} mapped, ${published} published`});});}
export function startAutomationWorker(){if(root.__swivelsWorker?.started)return;const state:State={started:true,busy:new Set()};root.__swivelsWorker=state;setTimeout(()=>queue(state),5_000).unref();setTimeout(()=>recovery(state),12_000).unref();setTimeout(()=>verify(state),20_000).unref();setTimeout(()=>catalog(state),30_000).unref();setTimeout(()=>reconcile(state),40_000).unref();setTimeout(()=>mana(state),60_000).unref();setInterval(()=>queue(state),15_000).unref();setInterval(()=>recovery(state),2*60_000).unref();setInterval(()=>catalog(state),10*60_000).unref();setInterval(()=>mana(state),2*60_000).unref();setInterval(()=>reconcile(state),15*60_000).unref();setInterval(()=>verify(state),30*60_000).unref();}
